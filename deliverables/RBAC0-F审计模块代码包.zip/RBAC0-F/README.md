# RBAC0 F 审计模块

请先阅读 F-审计模块使用说明.md。

源码在 backend/、frontend/，五份设计在 docs/detail-design/ 和 uml/detail-design/。

已编译后端在 build/rbac0-audit-1.0.0.jar，可使用 Java 17+ 执行：

```sh
java -jar build/rbac0-audit-1.0.0.jar --spring.profiles.active=demo
```

前端执行 npm ci 与 npm run dev 后访问开发服务器；frontend/dist 是已构建网页，需通过 HTTP 服务及 /api 代理访问，不能双击离线使用。

这只是 F 模块。demo 使用 H2，MySQL 和 A/E 认证需要进一步集成。
